# Gospel DESK — Android APK project

This project packages the supplied `Gospel DESK.html` as an Android app using Capacitor.

## Build the APK using GitHub Actions (no Android Studio required on your phone)

1. On a laptop, create a free GitHub account at https://github.com if you do not already have one.
2. Create a **new private repository** named `gospel-desk-android`.
3. Upload the contents of this folder to the repository (make sure `package.json`, `capacitor.config.json`, `www/`, and `.github/` are at the repository root).
4. Open the repository's **Actions** tab. If prompted, enable workflows.
5. Select **Build Gospel DESK APK** and choose **Run workflow** (or push to `main`).
6. When the run completes successfully, open it and download the `Gospel-DESK-debug-APK` artifact.
7. Extract the downloaded ZIP on your Android phone and tap `app-debug.apk` to install. Android may ask you to allow installs from that file manager/browser; only allow it for the app you used to download the APK.

## Build locally with Android Studio

Requirements: Node.js 20+, Java 21, Android Studio and Android SDK.

```bash
npm install
npx cap add android
npx cap sync android
npx cap open android
```

In Android Studio, build using **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

## App identity

- Name: Gospel DESK
- Android application ID: `ke.co.gospeldesk.app`
- Web entry point: `www/index.html`

## Important feature notes

- Sermon notes and imported Bible data use browser storage (localStorage and IndexedDB) inside the app's WebView. They are stored locally on that device; this starter does not sync them to another device.
- The supplied HTML includes only a small sample KJV text. A full Bible must be imported as a supported JSON file.
- The existing `claude.use(...)` integrations are host-environment integrations and are not automatically available in a standalone APK. The app falls back to basic local sermon summaries; this is not generative AI.
- Live speech transcription depends on browser/WebView speech-recognition support and runtime permissions. The starter declares microphone permission, but transcription must be tested on the target Android device. It does not save raw audio.
- PDF and PowerPoint libraries are loaded from CDNs in the original HTML, so those export functions require internet access and successful CDN loading.
- This is an unsigned **debug APK** for testing/personal installation, not a Play Store release. A signed release APK/AAB requires a signing key and a separate release build configuration.
